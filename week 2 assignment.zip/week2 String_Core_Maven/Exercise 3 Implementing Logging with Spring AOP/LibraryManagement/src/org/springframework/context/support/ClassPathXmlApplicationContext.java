package org.springframework.context.support;

import com.library.service.BookService;

public class ClassPathXmlApplicationContext {

	public BookService getBean(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
