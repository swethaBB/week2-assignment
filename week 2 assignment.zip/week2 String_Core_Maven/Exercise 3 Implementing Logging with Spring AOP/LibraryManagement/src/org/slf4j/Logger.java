package org.slf4j;

public class Logger {

	public void info(String string) {
		// TODO Auto-generated method stub
		
	}

}
