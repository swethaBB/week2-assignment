package org.aspectj.lang.annotation;

public class Around {

}
