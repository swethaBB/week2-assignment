

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;
import com.library.model.Book;

public class Main {
    public static void main(String[] args) {
        // Load Spring context
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();

        // Get BookService bean
        BookService bookService = (BookService) context.getBean("bookService");

        // Example usage
        System.out.println("All Books:");
        bookService.printAllBooks();

        System.out.println("\nAdding a new book...");
        Book newBook = new Book("978-0134694722", "Spring in Action", "Craig Walls");
        bookService.addBook(newBook);

        System.out.println("\nAll Books After Addition:");
        bookService.printAllBooks();

        System.out.println("\nFinding a book by ISBN:");
        Book foundBook = bookService.findBookByIsbn("978-0134694722");
        System.out.println(foundBook);

        System.out.println("\nDeleting a book by ISBN...");
        bookService.deleteBookByIsbn("978-0134694722");

        System.out.println("\nAll Books After Deletion:");
        bookService.printAllBooks();
    }
}
