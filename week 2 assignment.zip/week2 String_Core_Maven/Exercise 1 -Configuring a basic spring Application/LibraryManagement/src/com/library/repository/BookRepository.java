package com.library.repository;

import com.library.model.Book;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepository {
    private List<Book> books = new ArrayList<>();

    public BookRepository() {
        books.add(new Book("978-0134685991", "Effective Java", "Joshua Bloch"));
        books.add(new Book("978-0596009205", "Head First Java", "Kathy Sierra"));
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public Optional<Book> findByIsbn(String isbn) {
        return books.stream().filter(book -> book.getIsbn().equals(isbn)).findFirst();
    }

    public List<Book> findAll() {
        return new ArrayList<>(books);
    }

    public void deleteByIsbn(String isbn) {
        books.removeIf(book -> book.getIsbn().equals(isbn));
    }
}
